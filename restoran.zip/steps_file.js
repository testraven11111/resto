module.exports = function() {
  return actor({
  });
}
